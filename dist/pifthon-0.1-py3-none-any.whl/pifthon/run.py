from test import add


add(5)


add(6)

